import pyttsx3
import speech_recognition as sr
import datetime
import os
from tkinter import StringVar


engine = pyttsx3.init()
ru_voice_id = "HKEY_LOCAL_MACHINE\\SOFTWARE\\Microsoft\\Speech\\Voices\\Tokens\\TTS_MS_RU-RU_IRINA_11.0"
voices = engine.getProperty('voices')
engine.setProperty('voice', ru_voice_id)

voiceMessage_text = StringVar()
userMessage_text = StringVar()

def speak(audio):
    voiceMessage_text.set(audio)
    engine.say(audio)
    engine.runAndWait()


def wishMe():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak("Доброе утро! Я ваш ассистент Крис!")

    elif hour >= 12 and hour < 18:
        speak("Добрый день! Я ваш ассистент Крис!")

    else:
        speak("Доброго вечера! Я ваш ассистент Крис!")


def takeCommand():
    r = sr.Recognizer()

    with sr.Microphone() as source:

        speak("Слушаю")
        r.pause_threshold = 1
        audio = r.listen(source)

    try:
        query = r.recognize_google(audio, language='ru-RU')
        userMessage_text.set(query)

    except Exception as e:
        print(e)
        speak("Не удалось распознать вашу речь.")
        return 'None'

    return query


# Функции, которые написаны ниже были написаны для демонстрации работы записи и распознавания голоса пользователя.

def startVoice():

    clear = lambda: os.system('cls')

    clear()
    wishMe()

    while True:

        query = takeCommand().lower()

        if 'сколько' and 'прочитано' in query:
            with open('UserInfo.txt') as f:
                speak(f'Сейчас вы прочитали книг: {f.readlines()[3].count(' ')+1} ')
        elif 'сколько' and 'читаю' in query:
            with open('UserInfo.txt') as f:
                speak(f'Сейчас в статусе читаю: {f.readlines()[2].count(' ')+1} книг')
        elif 'сколько' and 'запланировано' in query:
            with open('UserInfo.txt') as f:
                speak(f'В "запланированно" у вас: {f.readlines()[1].count(' ')+1} книг')

        elif 'как дела' in query:
            speak("У меня всё хорошо. А как дела у вас?")

        elif 'хорошо' in query or "отлично" in query:
            speak("Рада слышать, что у вас всё хорошо!")

        elif 'выход' in query:
            speak("Спасибо за уделённое время!")
            return

        elif "я люблю тебя" in query:
            speak("Это тяжело понять...")
        else:
            speak("К сожалению, я не смог понять,\n что вы имели в виду...")
