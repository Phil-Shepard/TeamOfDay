import requests
import random


def Recomendations(Lib):
    if len(Lib) == 0:
        return None
    category = random.choice(list(set([genre for book in Lib for genre in book.categories.replace(' / ',', ').split(', ')])))
    print(category)
    index = random.randint(0,requests.get(f"https://www.googleapis.com/books/v1/volumes?q=subject:{category}").json()['totalItems'])
    print(index)
    return requests.get(f"https://www.googleapis.com/books/v1/volumes?q=subject:{category}"
                        f"&maxResults=1&startIndex={index}").json()


API_KEY = 'AIzaSyAJ1j8sZsZS0ZE5JmrLIh1naLYgRMv7dgQ'

# Получение рекомендации
# rec = Book.Book(Recomendations(Library).get('items', [{}])[0].get('id'))
# Recomendations(Library).get('items', [{}])[0].get('id')
